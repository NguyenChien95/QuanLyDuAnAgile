package datdvph44632.fpoly.duan1_appbanhang_dinhvandat.Entity;

public class Photo {
    private int resurceId ;

    public Photo(int resurceId) {
        this.resurceId = resurceId;
    }

    public int getResurceId() {
        return resurceId;
    }

    public void setResurceId(int resurceId) {
        this.resurceId = resurceId;
    }
}
